function antiAliasWrapper( inFile, outPrefix, movement, visualize )
%
% Anti-aliases. This function is just a wrapper around the
% antiAliasFunction being used.
%
% function antiAliasWrapper( inFile, outPrefix, movement )
%	Anti aliases a 3D binary image (1 inside, 0 outside and the boundary
% assumed to lie at 0.5); return a level-set with 0 representing the
% boundary. Movement should be [0.5 0.5] for strict antiAlias, anything
% more will result in smoothing. The first value is for the internal
% threshold, the second is for the outer threshold.
%

I = readMetaImage( inFile );

bandwidth = 6;

[antiAliased, K, H] = antiAlias3D_dH_flatRegions( I.I, 1, movement, bandwidth, 1000, I.spacing );

% xiaojie ---shift then time 100 for antiAliased 0421
% This is done for Pablo compatibility.
if nargin > 3
	if visualize
		I.I = antiAliased;
		writeMetaImage( I, [outPrefix '-antiAliased-visualization.mhd'],'MET_FLOAT');
	end
end

I.I = antiAliased*100 + 65536*max(-sign(antiAliased),0);

writeMetaImage( I, [outPrefix '-antiAliased.mhd'],'MET_USHORT');

end
